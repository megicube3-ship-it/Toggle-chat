package com.togglechat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class ToggleChatMod implements ClientModInitializer {

    public static boolean chatVisible = true;

    private static KeyBinding toggleChatKey;

    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("togglechat", "main"));

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("togglechat.properties");
    }

    private static void loadState() {
        Path path = configPath();
        if (!Files.exists(path)) {
            return;
        }
        try (InputStream in = Files.newInputStream(path)) {
            Properties props = new Properties();
            props.load(in);
            chatVisible = Boolean.parseBoolean(props.getProperty("chatVisible", "true"));
        } catch (IOException ignored) {
            // kalau gagal baca, tetap pakai default (chat terlihat)
        }
    }

    private static void saveState() {
        Properties props = new Properties();
        props.setProperty("chatVisible", Boolean.toString(chatVisible));
        try (OutputStream out = Files.newOutputStream(configPath())) {
            props.store(out, "Toggle Chat");
        } catch (IOException ignored) {
            // kalau gagal simpan, toggle tetap jalan di sesi ini
        }
    }

    @Override
    public void onInitializeClient() {
        loadState();

        // 72 = tombol H (GLFW_KEY_H), sama seperti versi sebelumnya
        toggleChatKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.togglechat.toggle", 72, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleChatKey.wasPressed()) {
                chatVisible = !chatVisible;
                saveState();
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal(chatVisible ? "§aChat GUI enabled" : "§cChat GUI disabled"),
                            true);
                }
            }
        });
    }
}

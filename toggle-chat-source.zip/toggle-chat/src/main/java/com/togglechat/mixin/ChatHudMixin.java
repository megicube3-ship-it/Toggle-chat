package com.togglechat.mixin;

import com.togglechat.ToggleChatMod;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public class ChatHudMixin {

    // Nama method ini sama persis dengan versi mod sebelumnya yang sudah terbukti jalan.
    @Inject(
            method = "method_75804(Lnet/minecraft/class_332;Lnet/minecraft/class_327;IIIZZ)V",
            at = @At("HEAD"),
            cancellable = true)
    private void onRender(DrawContext context, TextRenderer textRenderer, int currentTick,
                          int mouseX, int mouseY, boolean interactable, boolean bool,
                          CallbackInfo ci) {
        if (!ToggleChatMod.chatVisible) {
            ci.cancel();
        }
    }
}

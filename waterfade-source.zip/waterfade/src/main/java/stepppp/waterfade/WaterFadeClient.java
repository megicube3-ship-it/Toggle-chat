package stepppp.waterfade;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;

/**
 * Efek layar pudar + tetesan air setelah keluar dari air.
 * Kode asli (bukan salinan dari shader mana pun): hanya konsepnya yang sama,
 * yaitu efek yang meluruh perlahan setelah kepala keluar dari air.
 */
public class WaterFadeClient implements ClientModInitializer {

    // Lama efek (tick). 100 tick = 5 detik. Ubah sesuai selera.
    private static final int DURATION = 100;
    // Warna dasar kabut air (RGB), tidak termasuk alpha
    private static final int TINT = 0x9CC8E6;
    // Kekuatan maksimum kabut (0..255)
    private static final int MAX_ALPHA = 110;
    // Jumlah tetesan
    private static final int DROPS = 70;

    private static int timer = 0;
    private static int prevTimer = 0;
    private static boolean wasUnderwater = false;
    private static long seed = 1337L;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(WaterFadeClient::tick);

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("waterfade", "fade"),
                (graphics, tickCounter) -> render(graphics, tickCounter.getGameTimeDeltaPartialTick(false)));
    }

    private static void tick(Minecraft mc) {
        prevTimer = timer;
        if (mc.player == null) {
            timer = 0;
            wasUnderwater = false;
            return;
        }
        boolean under = mc.player.isEyeInFluid(FluidTags.WATER);
        if (wasUnderwater && !under) {
            timer = DURATION;
            prevTimer = DURATION;
            seed = System.nanoTime();
        }
        if (under) {
            timer = 0; // saat di dalam air, efek tidak aktif
        } else if (timer > 0) {
            timer--;
        }
        wasUnderwater = under;
    }

    private static void render(GuiGraphics g, float partial) {
        if (timer <= 0 && prevTimer <= 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        float t = Mth.lerp(partial, prevTimer, timer) / DURATION; // 1 -> 0
        if (t <= 0f) return;
        float eased = t * t; // meluruh cepat di awal, halus di akhir

        int w = g.guiWidth();
        int h = g.guiHeight();

        // 1) kabut tipis di seluruh layar
        int a = (int) (MAX_ALPHA * eased);
        g.fill(0, 0, w, h, (a << 24) | TINT);

        // 2) vinyet: tepi layar lebih berembun daripada tengah
        int edge = Math.max(2, h / 6);
        int ea = (int) (MAX_ALPHA * 0.8f * eased);
        for (int i = 0; i < edge; i += 2) {
            int ai = (int) (ea * (1f - (float) i / edge));
            int c = (ai << 24) | TINT;
            g.fill(0, i, w, i + 2, c);
            g.fill(0, h - i - 2, w, h - i, c);
            g.fill(i, 0, i + 2, h, c);
            g.fill(w - i - 2, 0, w - i, h, c);
        }

        // 3) tetesan air yang menetes ke bawah
        long s = seed;
        float progress = 1f - t; // 0 -> 1
        for (int i = 0; i < DROPS; i++) {
            s = s * 6364136223846793005L + 1442695040888963407L;
            float rx = ((s >>> 33) & 0xFFFF) / 65535f;
            s = s * 6364136223846793005L + 1442695040888963407L;
            float ry = ((s >>> 33) & 0xFFFF) / 65535f;
            s = s * 6364136223846793005L + 1442695040888963407L;
            float rs = ((s >>> 33) & 0xFFFF) / 65535f;

            // tetesan baru hilang secara bertahap, kecepatan tiap tetes beda
            float life = Mth.clamp(1f - progress * (0.7f + rs * 0.6f), 0f, 1f);
            if (life <= 0f) continue;

            int x = (int) (rx * w);
            int y = (int) ((ry + progress * (0.15f + rs * 0.35f)) * h) % h;
            int size = 2 + (int) (rs * 4f);
            int len = size * 2 + (int) (progress * h * 0.08f * rs); // jejak memanjang
            int da = (int) (150 * life);

            g.fill(x, y - len, x + 1, y, ((da / 3) << 24) | 0xFFFFFF);      // jejak
            g.fill(x, y, x + size, y + size, (da << 24) | 0xFFFFFF);        // tetes
            g.fill(x + 1, y + 1, x + size - 1, y + size - 1, ((da / 2) << 24) | 0x6FA8D0); // inti gelap
        }
    }
}
